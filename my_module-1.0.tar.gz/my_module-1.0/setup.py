from setuptools import setup, find_packages

setup(
    name="my_module",  # Name of your package
    version="1.0",
    packages=find_packages(),  # Automatically finds and includes the package
    install_requires=['pillow', 'numpy', 'matplotlib'],  # List of dependencies if any
)





